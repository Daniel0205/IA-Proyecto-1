#!/bin/bash

g++ -std=c++11 *.cpp -o run

array=()
while read STRING;
    do array+=("$STRING")
    done

./run ${array[@]}
