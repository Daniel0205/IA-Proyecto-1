#!/bin/bash

g++ -std=c++11 *.cpp -o run

./run $1
